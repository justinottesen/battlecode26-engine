package battlecode.instrumenter.sample.shared;

/**
 * @author james
 */
public class SharedUtility {
    public static int theNumberSeven() {
        return 7;
    }
}

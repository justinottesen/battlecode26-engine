package battlecode.instrumenter.sample.testplayerstatic;

import battlecode.common.Clock;
import battlecode.common.RobotController;

/**
 * @author james
 */
public class RobotPlayer {
    static {
        Clock.yield();
    }

    @SuppressWarnings("unused")
    public static void run(RobotController rc) {
        // Immediately return
    }
}

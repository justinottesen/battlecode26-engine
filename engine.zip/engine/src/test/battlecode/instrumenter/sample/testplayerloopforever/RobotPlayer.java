package battlecode.instrumenter.sample.testplayerloopforever;

import battlecode.common.RobotController;

/**
 * @author james
 */
public class RobotPlayer {
    public static void run(RobotController rc) {
        while (true) {}
    }
}

package battlecode.instrumenter.sample.instrumentertest;

/**
 * @author james
 */
@SuppressWarnings("unused")
public class StringFormat {
    public static void run() {
        String s = String.format("Test %d", 1);
    }
}

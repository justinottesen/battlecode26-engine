package battlecode.instrumenter.sample.instrumentertest;

/**
 * @author james
 */
public class Nothing {
}

package battlecode.instrumenter.sample.instrumentertest;

/**
 * @author james
 */
@SuppressWarnings("unused")
public class CallsMathRandom {
    private static final double d = Math.random();
}

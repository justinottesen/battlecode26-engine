// Javac will move this into the correct package in the build output
package battlecode.instrumenter.sample.instrumentertest;

/**
 * Test loading of inner classes.
 * 
 * @author james
 */
@SuppressWarnings("unused")
public class Outer {
    public static class Inner {
    }
}

package battlecode.instrumenter.sample.testplayerarray;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

/**
 * @author pear0 (William Gulian)
 */
public class RobotPlayer {
    public static void run(RobotController rc) throws GameActionException {

        RobotPlayer[] objects = new RobotPlayer[2];
        for (RobotPlayer o : objects) {
        }

        while (true);
    }
}

@file:JvmName("RobotPlayer")
@file:Suppress("PackageDirectoryMismatch")

package testplayerbytecodekotlin

import battlecode.common.RobotController

fun run(@Suppress("UNUSED_PARAMETER") rc: RobotController) {

    (1..1000).toList()

}
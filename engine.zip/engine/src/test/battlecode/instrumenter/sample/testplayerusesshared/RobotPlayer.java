package battlecode.instrumenter.sample.testplayerusesshared;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import battlecode.instrumenter.sample.shared.SharedUtility;

/**
 * @author james
 */
public class RobotPlayer {
    @SuppressWarnings("unused")
    public static void run(RobotController rc) throws GameActionException {
        // rc.broadcast(0, SharedUtility.theNumberSeven());
    }
}

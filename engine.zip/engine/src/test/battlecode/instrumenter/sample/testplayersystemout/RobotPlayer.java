package battlecode.instrumenter.sample.testplayersystemout;

import battlecode.common.RobotController;

import java.io.PrintStream;

/**
 * @author james
 */
public class RobotPlayer {
    public static void run(RobotController rc) {
        Class<?> k = System.class;
        PrintStream s = System.out;
        System.out.println("I LOVE MEMES");
        System.out.println("this shouldn't have a header");
    }
}

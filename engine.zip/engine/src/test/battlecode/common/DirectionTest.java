package battlecode.common;

import org.junit.Test;

import static org.junit.Assert.*;

public class DirectionTest {

    // TODO: write a bunch more of these

    // @Test
    // public void testBasic() {
    //     final Direction north = new Direction(0, 1);
    //     assertEquals(north.getDeltaX(0), 0, .00000001);
    //     assertEquals(north.getDeltaY(1), 1, .00000001);
    // }
}
